/*
Media Downloader Unleashed!! - https://github.com/helloyanis/media-downloader-unleashed/

Copyright © 2026 🦊 helloyanis

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// Description: This file contains the code to intercept media requests and responses and store them in session storage.
// The code is executed in the background script of the extension.

// Check for the existence of the browser object and use chrome if not found
if (typeof browser === 'undefined') {
    var browser = chrome;
}

const mediaTypes = [
    "video/x-flv",
    "video/x-msvideo",
    "video/x-ms-wmv",
    "video/quicktime",
    "video/mp4",
    "audio/x-pcm",
    "audio/wav",
    "audio/mpeg",
    "audio/aac",
    "audio/ogg",
    "audio/x-ms-wma",
    "application/vnd.apple.mpegurl",
    "application/x-mpegURL"
];

let urlList = [];
let headersSentListener, headersReceivedListener;

// ---------- IndexedDB helpers ----------
const DB_NAME = "MediaCacheDB";
const STORE_NAME = "network-cache";

function openCacheDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, 1);
        request.onerror = (event) => reject(event.target.error || "IDB Open Error");
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                db.createObjectStore(STORE_NAME, { keyPath: "url" });
            }
        };
        request.onsuccess = (event) => resolve(event.target.result);
    });
}

async function storeInCache(url, blob, headers, status) {
    try {
        const db = await openCacheDB();

        // Read existing item
        const cachedItem = await new Promise((resolve, reject) => {
            const tx = db.transaction([STORE_NAME], "readonly");
            const store = tx.objectStore(STORE_NAME);
            const req = store.get(url);

            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });

        const item = {
            url,
            headers: headers || cachedItem?.headers || {},
            status: status || cachedItem?.status || "000",
            data: blob || cachedItem?.data,
            timestamp: cachedItem?.timestamp || Date.now()
        };

        if (cachedItem) {
            item.mime = cachedItem.mime;
        }

        // Create write transaction only now
        await new Promise((resolve, reject) => {
            const tx = db.transaction([STORE_NAME], "readwrite");
            const store = tx.objectStore(STORE_NAME);

            const req = store.put(item);

            req.onsuccess = () => resolve();
            req.onerror = () => reject(req.error);

            tx.onabort = () => reject(tx.error);
            tx.onerror = () => reject(tx.error);
        });
    } catch (e) {
        console.error("Failed to store in cache:", e);
    }
}

async function addHeadersToCache(url, headers, status) {
    try {
        const db = await openCacheDB();

        // Read first
        const cachedItem = await new Promise((resolve, reject) => {
            const tx = db.transaction([STORE_NAME], "readonly");
            const store = tx.objectStore(STORE_NAME);
            const req = store.get(url);

            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });

        if (!cachedItem) {
            console.debug("Attempted to add headers to an item not in cache. Adding it!");
            await storeInCache(url,null,headers, status)
            return;
        }

        const newItem = {
            url: cachedItem.url,
            headers,
            status,
            data: cachedItem.data,
            timestamp: cachedItem.timestamp // check spelling here
        };

        // Create a fresh write transaction
        await new Promise((resolve, reject) => {
            const tx = db.transaction([STORE_NAME], "readwrite");
            const store = tx.objectStore(STORE_NAME);

            const req = store.put(newItem);

            req.onsuccess = () => resolve();
            req.onerror = () => reject(req.error);
        });
    } catch (e) {
        console.error("Failed to add mime to cache:", e);
    }
}
// -------------------------------------------------------------------------------

// ----- extension lists for url-detection -----
const videoExtensions = [".3g2", ".3gp", ".asx", ".avi", ".divx", ".4v", ".flv", ".ismv", ".m2t", ".m2ts", ".m2v", ".m4s", ".m4v", ".mk3d", ".mkv", ".mng", ".mov", ".mp2v", ".mp4", ".mp4v", ".mpe", ".mpeg", ".mpeg1", ".mpeg2", ".mpeg4", ".mpg", ".mxf", ".ogm", ".ogv", ".qt", ".rm", ".swf", ".ts", ".vob", ".vp9", ".webm", ".wmv"];
const audioExtensions = [".3ga", ".aac", ".ac3", ".adts", ".aif", ".aiff", ".alac", ".ape", ".asf", ".au", ".dts", ".f4a", ".f4b", ".flac", ".isma", ".it", ".m4a", ".m4b", ".m4r", ".mid", ".mka", ".mod", ".mp1", ".mp2", ".mp3", ".mp4a", ".mpa", ".mpga", ".oga", ".ogg", ".ogx", ".opus", ".ra", ".shn", ".spx", ".vorbis", ".wav", ".weba", ".wma", ".xm"];
const streamExtensions = [".f4f", ".f4m", ".m3u8", ".mpd", ".smil"];

const allExtensions = videoExtensions.concat(audioExtensions, streamExtensions);
// build a safe regex from extensions (escape dots already present)
const extPattern = allExtensions.map(e => e.replace(/^\./, '').replace(/\+/g, '\\+')).join('|');
const detectionRegex = new RegExp('\\.(?:' + extPattern + ')(?:[?#].*)?$', 'i');
const temporaryHeaderMap = new Map();
const temporaryRequestBodyMap = new Map();
const temporaryCookieMap = new Map();

// helper to interpret setting values
function isFlagEnabled(val) {
    return val === '1' || val === 1 || val === true || val === 'true';
}

// get local settings
function getSettings(callback) {
    browser.storage.local.get(['mime-detection', 'url-detection','media-cache','media-cache-private'], function (result) {
        // If settings are not present yet (first run), assume defaults matching settings.js (enabled = '1')
        const mimeRaw = Object.prototype.hasOwnProperty.call(result, 'mime-detection') ? result['mime-detection'] : '1';
        const urlRaw = Object.prototype.hasOwnProperty.call(result, 'url-detection') ? result['url-detection'] : '1';
        const mediaCache = Object.prototype.hasOwnProperty.call(result, 'media-cache') ? result['media-cache'] : '1';
        const mediaCachePrivate = Object.prototype.hasOwnProperty.call(result, 'media-cache-private') ? result['media-cache-private'] : '0';
        callback({
            mimeDetection: isFlagEnabled(mimeRaw),
            urlDetection: isFlagEnabled(urlRaw),
            mediaCache: isFlagEnabled(mediaCache),
            mediaCachePrivate: isFlagEnabled(mediaCachePrivate)
        });
    });
}

// Helper: convert ArrayBuffer to base64 safely in chunks
function arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    const chunkSize = 0x8000; // 32KB chunks
    let binary = '';
    for (let i = 0; i < bytes.length; i += chunkSize) {
        const chunk = bytes.subarray(i, i + chunkSize);
        binary += String.fromCharCode.apply(null, chunk);
    }
    return btoa(binary);
}

let beforeRequestListener, beforeSendHeadersListener;

function initListener() {
    // Clear indexedDB cache on init to avoid stale data
    openCacheDB().then(db => {
        const tx = db.transaction([STORE_NAME], "readwrite");
        const store = tx.objectStore(STORE_NAME);
        store.clear();
    }).catch(e => {
        console.error("Failed to clear IndexedDB cache on init:", e);
    });
    // Decide which urls we will watch for onSendHeaders/onHeadersReceived - keep default <all_urls>
    urlList = ["<all_urls>"];

    // Read settings and then attach listeners accordingly
    getSettings(function (settings) {
        const mimeEnabled = !!settings.mimeDetection;
        const urlEnabled = !!settings.urlDetection;
        const mediaCacheEnabled = !!settings.mediaCache
        const mediaCachePrivateEnabled = !!settings.mediaCachePrivate

        console.log('initListener settings: mimeEnabled=', mimeEnabled, 'urlEnabled=', urlEnabled);

        // Remove existing listeners if present
        if (headersSentListener) {
            try { browser.webRequest.onSendHeaders.removeListener(headersSentListener); } catch (e) { }
        }
        if (beforeSendHeadersListener) {
            try { browser.webRequest.onBeforeSendHeaders.removeListener(beforeSendHeadersListener); } catch (e) { }
        }
        if (headersReceivedListener) {
            try { browser.webRequest.onHeadersReceived.removeListener(headersReceivedListener); } catch (e) { }
        }
        if (beforeRequestListener) {
            try { browser.webRequest.onBeforeRequest.removeListener(beforeRequestListener); } catch (e) { }
            beforeRequestListener = null;
        }

        const cleanupListener = (details) => {
            if (temporaryHeaderMap.has(details.requestId)) {
                temporaryHeaderMap.delete(details.requestId);
            }
            if (temporaryRequestBodyMap.has(details.requestId)) {
                temporaryRequestBodyMap.delete(details.requestId);
            }
            if (temporaryCookieMap.has(details.url)) {
                temporaryCookieMap.delete(details.url);
            }
        };
        // Ensure we don't duplicate cleanup listeners if initListener runs multiple times
        if (!browser.webRequest.onCompleted.hasListener(cleanupListener)) {
            browser.webRequest.onCompleted.addListener(cleanupListener, { urls: ["<all_urls>"] });
            browser.webRequest.onErrorOccurred.addListener(cleanupListener, { urls: ["<all_urls>"] });
        }

        // NEW: capture request bodies in onBeforeRequest (formData or raw bytes).
        beforeRequestListener = function (details) {
            try {
                if (!details || !details.requestBody) return;

                const rb = details.requestBody;

                if (rb.formData) {
                    // formData is an object of arrays; safe to store directly
                    temporaryRequestBodyMap.set(details.requestId, { type: 'formData', data: rb.formData });
                } else if (rb.raw && rb.raw.length) {
                    // raw may contain an ArrayBuffer/Uint8Array in .bytes
                    try {
                        // Combine all raw parts into one ArrayBuffer (if multiple)
                        let totalLen = 0;
                        for (let part of rb.raw) {
                            if (part && part.bytes) {
                                totalLen += part.bytes.byteLength || part.bytes.length || 0;
                            }
                        }
                        if (totalLen === 0) {
                            // nothing to store
                            return;
                        }
                        // create combined buffer
                        const combined = new Uint8Array(totalLen);
                        let offset = 0;
                        for (let part of rb.raw) {
                            if (!part || !part.bytes) continue;
                            const src = new Uint8Array(part.bytes);
                            combined.set(src, offset);
                            offset += src.length;
                        }
                        const base64 = arrayBufferToBase64(combined.buffer);
                        temporaryRequestBodyMap.set(details.requestId, { type: 'base64', data: base64 });
                    } catch (e) {
                        console.warn("Failed to serialize raw request body for requestId", details.requestId, e);
                    }
                }
            } catch (e) {
                console.error("Error in onBeforeRequest listener (requestBody capture):", e);
            }
        };

        // Attach beforeRequest listener to capture requestBody. Guard for availability.
        try {
            if (browser.webRequest && browser.webRequest.onBeforeRequest && !browser.webRequest.onBeforeRequest.hasListener(beforeRequestListener)) {
                browser.webRequest.onBeforeRequest.addListener(
                    beforeRequestListener,
                    { urls: urlList },
                    ['requestBody']
                );
            }
        } catch (e) {
            console.warn("Failed to attach onBeforeRequest requestBody listener:", e);
        }

        beforeSendHeadersListener = async function (details) {
            const protocol = new URL(details.originUrl).protocol
            if(protocol === 'moz-extension:' || protocol === 'chrome-extension:') {
                // Requests is from extension itself, so try to add cookies
                try {
                    const cookie = temporaryCookieMap.get(details.url) || '';
                    if (cookie) {
                        details.requestHeaders.push({ name: 'Cookie', value: cookie });
                        console.debug("Added Cookie header to extension request:", cookie);
                    }
                } catch (e) {
                    console.error("Error adding Cookie header to extension request:", e);
                }
            }
            else {
                // For non-extension requests, we rely on onHeadersReceived to get cookies from response
                console.debug("Details:", details);

                const cookie = details.requestHeaders.find(h => h.name.toLowerCase() === 'cookie')?.value || '';
                if (cookie) {
                    console.debug("Saving request cookie :", cookie);
                }
                
                //Store the cookies from request headers into the corresponding request object in existingRequests
                temporaryCookieMap.set(details.url, cookie);

                // Also, if cache is enabled, remove the Range header from outgoing requests to cache the whole file
                if((mediaCacheEnabled && !details.incognito) || (mediaCachePrivateEnabled && details.incognito)){
                    const range = details.requestHeaders.find(h => h.name.toLowerCase() === 'range')?.value || '';
                    if(range){
                        details.requestHeaders = details.requestHeaders.filter(header => header.name.toLowerCase() != 'range');
                    }
                }

            }
            return { requestHeaders: details.requestHeaders };
        };

        browser.webRequest.onBeforeSendHeaders.addListener(
            beforeSendHeadersListener,
            { urls: urlList },
            ['requestHeaders', 'blocking']
        );
        console.log("Attached onBeforeSendHeaders listener.");

        headersSentListener = async function (details) {
            try {
                // [NEW] Always capture headers to the temporary map first
                if (details.requestHeaders) {
                    temporaryHeaderMap.set(details.requestId, details.requestHeaders);
                }

                const urlMatches = detectionRegex.test(decodeURI(details.url));

                // If neither flag is enabled -> save all (original behavior)
                if (!mimeEnabled && !urlEnabled) {
                    // Save as before
                } else {
                    // If url-detection enabled and URL matches -> save
                    if (!urlEnabled || (urlEnabled && !urlMatches)) {
                        // If url-detection enabled but URL doesn't match, and mime-detection is enabled,
                        // then we should NOT save now (wait for onHeadersReceived). So skip saving here.
                        if (urlEnabled && mimeEnabled && !urlMatches) {
                            // wait for onHeadersReceived to decide
                            return;
                        }
                        if (mimeEnabled && !urlEnabled) {
                            return;
                        }
                        // If urlEnabled is true and urlMatches is true -> fallthrough to save
                        // Otherwise, if logic reaches here but conditions didn't match, skip
                    }
                }

                // At this point either:
                // - neither flag set (=> save all), or
                // - urlEnabled && urlMatches (=> save), or
                // - both enabled and urlMatches (=> save)
                // [NEW] Retrieve any cached request body
                const cachedBody = temporaryRequestBodyMap.get(details.requestId) || null;
                

                let mediaRequest = {
                    requestId: details.requestId,
                    url: details.url,
                    method: details.method,
                    requestHeaders: details.requestHeaders,
                    responseHeaders: null,
                    requestBody: cachedBody,
                    cookie: temporaryCookieMap.get(details.url) || '',
                    size: null,
                    timeStamp: null
                };

                browser.storage.session.get(details.url, function (result) {
                    let existingRequests = result[details.url] || [];

                    // push the new request
                    existingRequests.push(mediaRequest);
                    let requestsObj = {};
                    requestsObj[details.url] = existingRequests;
                    browser.storage.session.set(requestsObj);
                    console.log('Media request intercepted (onSendHeaders):', mediaRequest);
                });
            } catch (e) {
                console.error("Error in onSendHeaders handler:", e);
            }
        };

        browser.webRequest.onSendHeaders.addListener(
            headersSentListener,
            { urls: urlList },
            ['requestHeaders']
        );

        // onHeadersReceived: used to update size/responseHeaders and also to save requests when mime-detection triggers
        headersReceivedListener = async function (details) {
            try {
                // Extract content-length and content-type (if present)
                const responseHeaders = details.responseHeaders || [];
                let mediaSizeHeader = responseHeaders.find(header => header.name && header.name.toLowerCase() === 'content-length');
                let size = mediaSizeHeader ? mediaSizeHeader.value : 'unknown';

                let contentTypeHeader = responseHeaders.find(header => header.name && header.name.toLowerCase() === 'content-type');
                let contentType = contentTypeHeader ? (contentTypeHeader.value || '').toLowerCase() : '';

                // Normalize contentType (strip parameters)
                if (contentType.indexOf(';') !== -1) {
                    contentType = contentType.split(';')[0].trim().toLowerCase();
                }

                const mimeMatches = (
                    contentType.startsWith('audio/') ||
                    contentType.startsWith('video/') ||
                    contentType === 'application/vnd.apple.mpegurl' ||
                    contentType === 'application/x-mpegurl' ||
                    contentType === 'application/dash+xml' ||
                    contentType === 'application/octet-stream' // <-- treat generic binary as potential media (or segments)
                );

                const urlMatches = detectionRegex.test(decodeURI(details.url));

                // Retrieve existing stored requests for this URL (if any)
                browser.storage.session.get(details.url, function (result) {
                    let existingRequests = result[details.url] || [];

                    // Try to find a previously created request to update it
                    let updated = false;
                    for (let request of existingRequests) {
                        // If the request has no size / responseHeaders yet, update it
                        if (!request.size && (!request.responseHeaders || request.responseHeaders === null)) {
                            request.size = size;
                            request.responseHeaders = responseHeaders;
                            request.timeStamp = details.timeStamp;
                            updated = true;
                            break;
                        }
                    }

                    if(contentTypeHeader && ((mediaCacheEnabled && !details.incognito) || (mediaCachePrivateEnabled && details.incognito))) {
                        addHeadersToCache(details.url, responseHeaders, details.statusCode)
                        console.debug("Added type", contentType, "to URL", details.url)
                    }

                    // Decide whether to add a new request entry in cases where onSendHeaders did not add one:
                    // - If neither flag set -> onSendHeaders already added, so we should have updated above.
                    // - If mime-detection only and mimeMatches -> add new entry here
                    // - If both enabled and neither matched onSendHeaders but mimeMatches now -> add
                    // - If url-detection only, we would have saved at onSendHeaders; no need to add here.
                    // So add if:
                    // (mimeEnabled && mimeMatches) OR (urlEnabled && urlMatches AND no existing request present)
                    // but guard against duplicates: only push if `updated` is false AND the saving condition matches.

                    getSettings(async function (currentSettings) {
                        const mimeEnabledNow = !!currentSettings.mimeDetection;
                        const urlEnabledNow = !!currentSettings.urlDetection;

                        const shouldSaveNow = (() => {
                            if (!mimeEnabledNow && !urlEnabledNow) return true;
                            if (mimeEnabledNow && mimeMatches) return true;
                            if (urlEnabledNow && urlMatches) return true;
                            return false;
                        })();

                        if (!updated && shouldSaveNow) {
                            // [NEW] Retrieve the stashed request headers and request body using requestId
                            const cachedHeaders = temporaryHeaderMap.get(details.requestId) || null;
                            const cachedBody = temporaryRequestBodyMap.get(details.requestId) || null;

                            let mediaRequest = {
                                requestId: details.requestId,
                                url: details.url,
                                method: details.method || 'GET',
                                requestHeaders: cachedHeaders,
                                responseHeaders: responseHeaders,
                                requestBody: cachedBody, // <-- now populated if available
                                cookie: temporaryCookieMap.get(details.url) || '',
                                size: size,
                                timeStamp: details.timeStamp
                            };
                            existingRequests.push(mediaRequest);
                            console.log('Media request added (onHeadersReceived):', mediaRequest);
                        } else if (updated) {
                            console.log('Media response updated (onHeadersReceived) for', details.url);
                        }

                        let requestsObj = {};
                        requestsObj[details.url] = existingRequests;
                        browser.storage.session.set(requestsObj);
                    });
                });
            } catch (e) {
                console.error("Error in onHeadersReceived handler:", e);
            }
        };

        browser.webRequest.onHeadersReceived.addListener(
            headersReceivedListener,
            { urls: urlList },
            ['responseHeaders']
        );
    });
}

// Send media request data to the popup (session storage is not shared between background and popup scripts)
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getMediaRequests') {
        browser.storage.session.get(null, function (items) {
            // Clear the completedDownloads and failedDownloads keys from the response, as they are only relevant for the popup's own session and should not be shared with the background script or other popups.
            delete items['completedDownloads'];
            delete items['failedDownloads'];
            delete items['queuedAndroidDownloads'];
            delete items['pendingPopupState'];
            sendResponse(items);
        });
        return true; // Indicate that the response will be sent asynchronously
    }
});

// Initialize the listener
initListener();

// Clear local storage when message is received (clear list button)
browser.runtime.onMessage.addListener((message) => {
    if (message.action === 'clearStorage') {

        // Do not clear data for ongoing downloads
        const ongoingDownloads = message.ongoingDownloads || [];
        const ongoingIDs = new Set(ongoingDownloads.map(d => d.requestId));
        const ongoingURLs = new Set(ongoingDownloads.map(d => d.url));

        browser.storage.session.get(null, function (items) {
            for (let url in items) {
                const requests = items[url];
                const filteredRequests = requests.filter(r => ongoingIDs.has(r.requestId));
                if (filteredRequests.length > 0) {
                    let obj = {};
                    obj[url] = filteredRequests;
                    browser.storage.session.set(obj);
                } else {
                    browser.storage.session.remove(url);
                }
            }
        });

        // Also clear IndexedDB entries that are not related to ongoing downloads
        openCacheDB().then(db => {
            const tx = db.transaction([STORE_NAME], "readwrite");
            const store = tx.objectStore(STORE_NAME);
            const request = store.openCursor();
            request.onsuccess = function (event) {
                const cursor = event.target.result;
                if (cursor) {
                    if (!ongoingURLs.has(cursor.value.url)) {
                        // No ongoing download for this URL, safe to delete
                        store.delete(cursor.primaryKey);
                    }
                    cursor.continue();
                }
            };
        }).catch(e => {
            console.error("Failed to clear IndexedDB cache:", e);
        });
    }
});

// This is used to open the popup.html file when the add-on icon is clicked, and to open the installed.md and when the add-on is installed.
browser.action.onClicked.addListener((tab) => {
    browser.storage.local.get('open-preference', async function (result) {
        console.log('Open preference:', result['open-preference']);
        if (result['open-preference'] === 'window') {
            browser.windows.create({
                url: browser.runtime.getURL(`popup.html`),
                type: 'popup',
                width: 800,
                height: 600,
            });
        } else if (result['open-preference'] === 'floating') {
            await browser.action.setPopup({ popup: 'popup.html' });
            console.log( await browser.action.getPopup({}))
            await browser.action.openPopup(); // Open in default popup behavior (floating window)
            await browser.action.setPopup({ popup: null }); // Reset to no popup in case the user changes preference while the popup is open
        }else {
            // Open the popup in a new tab
            browser.tabs.create({
                url: browser.runtime.getURL(`popup.html`),
            });
        }
    });
});

browser.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        browser.tabs.create({
            url: `https://github.com/helloyanis/media-downloader-unleashed/blob/master/src/installed.md#thank-you-for-installing-the-media-downloader-unleashed-add-on`,
        });
    }
});

browser.runtime.onStartup.addListener(initListener);

browser.runtime.setUninstallURL(`https://forms.gle/Q5j2147qNkJnftU19`);

// ----------------- Capture & cache media response bodies -----------------
// We use onHeadersReceived to detect Content-Type, and if it's a media type we attach
// a filterResponseData stream to capture the response body and store it into IndexedDB.
// ------------------------------------------------------------------------------

let cacheListener = null;
let mediaCacheEnabled = false;
let mediaCachePrivateEnabled = false;

// helper to safely remove current listener
function detachCacheListener() {
    if (!cacheListener) return;
    try {
        browser.webRequest.onBeforeRequest.removeListener(cacheListener);
    } catch (e) { /* ignore if already removed */ }
    cacheListener = null;
    console.debug("Cache listener detached.");
}

// attach listener (only when we already know mediaCacheEnabled === true)
function attachCacheListener() {
    if (cacheListener) return; // already attached

    // guard: if runtime doesn't support filterResponseData, don't attach
    if (!browser.webRequest || !browser.webRequest.filterResponseData) {
        console.warn("filterResponseData not available; not attaching cache listener.");
        return;
    }

    cacheListener = (details) => {
        try {
            // quick checks; avoid any async storage calls here
            if (details.incognito) return;

            // attach filter to stream & capture the response body
            let filter;
            try {
                filter = browser.webRequest.filterResponseData(details.requestId);
            } catch (e) {
                console.warn("filterResponseData failed for requestId", details.requestId, e);
                return;
            }

            const chunks = [];
            filter.ondata = (event) => {
                try {
                    chunks.push(event.data);
                    filter.write(event.data);
                } catch (e) {
                    console.error("Error writing chunk back to filter:", e);
                }
            };
            filter.onstop = async () => {
                try {
                    filter.disconnect();
                    const blob = new Blob(chunks, { type: 'application/octet-stream' });
                    if (blob.size > 0) {
                        if ((mediaCacheEnabled && !details.incognito) || (mediaCachePrivateEnabled && details.incognito)) {
                            await storeInCache(details.url, blob, null, null); // Headers and status will be populated in headersReceivedListener
                            console.log("Cached response for:", details.url, "bytes:", blob.size);
                        } else {
                            console.debug("Skipping cache because setting is disabled", details.url, "is incognito : ",details.incognito)
                        }
                    } else {
                        console.warn("Skipping cache for empty response:", details.url);
                    }
                } catch (e) {
                    console.error("Failed to cache response body for", details.url, e);
                }
            };
            filter.onerror = (err) => {
                try { filter.disconnect(); } catch (e) {}
                console.error(`Filter error for request ${details.requestId}`, err);
            };
        } catch (e) {
            console.error("Error in cache listener:", e);
        }
    };

    browser.webRequest.onBeforeRequest.addListener(
        cacheListener,
        { urls: ["<all_urls>"], /*types: ["media", "object"]*/ }, // Types can't work with MPD files as the MPD request is categorized as "xmlhttprequest"
        ["blocking"]
    );

    console.debug("Cache listener attached.");
}

// read initial setting from storage and attach/detach accordingly
async function initCacheState() {
    try {
        const resCache = await browser.storage.local.get('media-cache');
        const enabled = !!isFlagEnabled(resCache['media-cache']);
        mediaCacheEnabled = enabled
        const resCachePrivate = await browser.storage.local.get('media-cache-private');
        const enabledPrivate = !!isFlagEnabled(resCache['media-cacheprivate']);
        mediaCachePrivateEnabled = enabledPrivate

        console.debug("Initialized cache state, with cache", mediaCacheEnabled," and private cache",mediaCachePrivateEnabled)

        attachCacheListener(); // Since we now do a distinction between private and non private caches, we just always attach the listener, and save depending on the incognito context of the resuest inside of the listener.
    } catch (e) {
        console.error("Failed to read media-cache setting:", e);
        // default to detached to avoid blocking requests
        mediaCacheEnabled = false;
        mediaCachePrivateEnabled = false;
        detachCacheListener();
    }
}

// watch for runtime changes to storage and update attachment immediately
browser.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (Object.prototype.hasOwnProperty.call(changes, 'media-cache')){
        const newEnabled = !!isFlagEnabled(changes['media-cache'].newValue);
        mediaCacheEnabled = newEnabled
        console.debug("Changed media cache to", mediaCacheEnabled)
    };
    if (Object.prototype.hasOwnProperty.call(changes, 'media-cache-private')){
        const newEnabled = !!isFlagEnabled(changes['media-cache-private'].newValue);
        mediaCachePrivateEnabled = newEnabled
        console.debug("Changed private media cache to", mediaCachePrivateEnabled)
    };
});

// optional: message API to force re-init from elsewhere
browser.runtime.onMessage.addListener((message) => {
    if (message && message.action === 'initCacheListener') {
        initCacheState();
    }
});

// do initial setup
initCacheState();
